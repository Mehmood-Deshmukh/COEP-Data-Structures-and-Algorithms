typedef struct Time{
    int hours;
    int minutes;
    int seconds;
} Time;

Time add(Time t1, Time t2);
Time substract(Time t1, Time t2);
