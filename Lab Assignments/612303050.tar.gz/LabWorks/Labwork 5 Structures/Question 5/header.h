typedef struct Fraction{
    int numerator;
    int denominator;
} Fraction;

int compare(Fraction x, Fraction y);