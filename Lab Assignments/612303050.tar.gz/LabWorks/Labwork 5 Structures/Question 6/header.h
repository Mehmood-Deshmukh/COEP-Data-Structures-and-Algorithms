typedef struct Date{
    int day;
    int month;
    int year;
} Date;

int isLeapYear(Date date);
int isvalid(Date date);
void printDate(Date date);