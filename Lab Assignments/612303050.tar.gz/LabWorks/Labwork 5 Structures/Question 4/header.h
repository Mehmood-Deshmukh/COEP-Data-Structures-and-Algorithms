typedef struct Time {
    int hours;
    int minutes;
    int seconds;
} Time;

void printGoodDay(Time startTime, Time endTime);